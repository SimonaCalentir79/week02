// using System;

// namespace ConsoleApplication 
// {
//     public class DisplayNumbers 
//     {
//         public static void Main()
//         {
//             bool goon = true;
//             for(int i = 10;goon;i--)
//             {
//                 Console.WriteLine(i);
//                 if(i == -10)
//                 {
//                     goon = false;
//                 }
//             }

//         }
//     } 
// }