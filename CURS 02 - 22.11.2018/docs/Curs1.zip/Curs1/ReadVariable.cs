// using System;

// namespace ConsoleApplication
// {
//    public class ReadVariable
//    {
//        public static void Main()
//        {
//            string temp = Console.ReadLine();
//            int number = Convert.ToInt32(temp);
//            if (number > 100) 
//            {
//                Console.WriteLine("Number is bigger than 100");
//            }
//            else if (number < 100)
//            {
//                Console.WriteLine("Number is smaller than 100");
//            }
//            else 
//            {
//                 Console.WriteLine("Number is equal to 100");
//            }
//        }
//    }
// }
