﻿// using System;

// namespace Curs1
// {
//     class Program2
//     {
//         static void Main(string[] args)
//         {
//             Console.WriteLine("Hello World!");
//         }
//     }
// }
