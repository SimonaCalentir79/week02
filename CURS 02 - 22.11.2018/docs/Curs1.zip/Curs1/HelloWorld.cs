// using System;

// namespace Curs1
// {
//    public class HelloWorld
//    {
//        public static void Main()
//        {
//            Console.WriteLine("Salut Liviu!");
//        }
//    }
// }
